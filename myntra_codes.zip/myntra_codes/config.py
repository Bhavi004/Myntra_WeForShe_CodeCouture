RAPID_API_KEY = "be89193195mshe82211e2240cc7cp1e3fc0jsn9e358f37c1ed"
LOOK_URI = "https://github.com/Bhavi004/Myntra_WeForShe_CodeCouture/blob/main/sample_clothes_images.jpg"
AVATAR_URI = "https://github.com/Bhavi004/Myntra_WeForShe_CodeCouture/blob/main/sample_avatar_image.jpg"

