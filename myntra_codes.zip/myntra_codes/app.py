import streamlit as st
import pandas as pd
from PIL import Image, UnidentifiedImageError
import os
import requests
from google.cloud import aiplatform
import google.generativeai as genai
import ast
import base64


api_key = "AIzaSyD_BY7nkCJhmId3yOIoULOMjmuNNT8xZhQ"
genai.configure(api_key=api_key)

model = genai.GenerativeModel('gemini-1.5-flash')

RAPID_API_KEY = "848a5abc67mshe9c555a04568965p188045jsn6f6c433818e0"
#LOOK_PATH = "C:/Users/bhavi/Downloads/catalogue_dataset/12.png"
#AVATAR_PATH = "C:/Users/bhavi/Downloads/demo.jpg"


def encode_image_to_base64(image_path):
    with open(image_path, "rb") as image_file:
        return base64.b64encode(image_file.read()).decode('utf-8')


# def virtual_try_on():
# #def virtual_try_on(look_image_path, avatar_image_path):
#     #look_image_base64 = encode_image_to_base64(r')
#     #avatar_image_base64 = encode_image_to_base64(avatar_image_path)

#     look_image_base64 = encode_image_to_base64(LOOK_PATH)
#     avatar_image_base64 = encode_image_to_base64(AVATAR_PATH)

#     params = {
#         'clothing_image_base64': look_image_base64,
#         'avatar_image_base64': avatar_image_base64
#     }

#     headers = {
#         'Content-Type': 'application/x-www-form-urlencoded',
#         'X-RapidAPI-Key': RAPID_API_KEY,
#         'X-RapidAPI-Host': 'texel-virtual-try-on.p.rapidapi.com'
#     }

#     try:
#         response = requests.post(
#             'https://texel-virtual-try-on.p.rapidapi.com/try-on-url',
#             headers=headers,
#             data=params
#         )
#         with open('result.jpg', 'wb') as output_file:
#             output_file.write(response.content)
#         return 'result.jpg'
#     except requests.exceptions.RequestException as error:
#         print('Error:', error)
#         return None


def virtual_try_on(look_image_path, avatar_image_file):
    LOOK_PATH = r'C:/Users/bhavi/Downloads/catalogue_dataset/12.png'
    AVATAR_PATH = r'C:/Users/bhavi/Downloads/demo.jpg'
    look_image_base64 = encode_image_to_base64(LOOK_PATH)
    avatar_image_base64 = base64.b64encode(AVATAR_PATH)  

    params = {
        'clothing_image_base64': look_image_base64,
        'avatar_image_base64': avatar_image_base64
    }

    headers = {
        'Content-Type': 'application/x-www-form-urlencoded',
        'X-RapidAPI-Key': RAPID_API_KEY,
        'X-RapidAPI-Host': 'texel-virtual-try-on.p.rapidapi.com'
    }

    try:
        response = requests.post(
            'https://texel-virtual-try-on.p.rapidapi.com/try-on-url',
            headers=headers,
            data=params
        )
        if response.status_code == 200:
            result_image_path = 'result.jpg'
            with open(result_image_path, 'wb') as output_file:
                output_file.write(response.content)
            return result_image_path
        else:
            print(f'Error: {response.status_code}, {response.text}')
            return None
    except requests.exceptions.RequestException as error:
        print('Error:', error)
        return None



# Load the datasets
@st.cache_data
def load_data(file_path):
    data = pd.read_excel(file_path)
    data['image_path'] = data['image_path'].apply(lambda x: x.replace('\\', '/'))
    return data

# Load theme-specific data
@st.cache_data
def load_theme_data(file_path):
    data = pd.read_csv(file_path)
    data['image_path'] = data['image_path'].apply(lambda x: x.replace('\\', '/'))
    return data

if not os.path.exists('uploads'):
    os.makedirs('uploads')

if 'playlists' not in st.session_state:
    st.session_state['playlists'] = {}


def add_to_playlist(occasion, item):
    if occasion not in st.session_state['playlists']:
        st.session_state['playlists'][occasion] = []
    # Check if item is already in the playlist
    if item not in st.session_state['playlists'][occasion]:
        st.session_state['playlists'][occasion].append(item)
        st.success(f'Added {item["name"]} to {occasion} playlist')
    else:
        st.warning(f'{item["name"]} is already in {occasion} playlist')


def save_uploaded_file(uploaded_file):
    file_path = os.path.join('uploads', uploaded_file.name)
    with open(file_path, 'wb') as f:
        f.write(uploaded_file.getbuffer())
    return file_path


def remove_from_playlist(occasion, item_name):
    if occasion in st.session_state['playlists']:
        st.session_state['playlists'][occasion] = [item for item in st.session_state['playlists'][occasion] if
                                                   item['name'] != item_name]
        st.success(f'Removed {item_name} from {occasion} playlist')




def predict_size(height, weight, body_shape, gender, product_fit):

    if gender == 'M':
        size_chart_path = r'C:\Users\bhavi\Downloads\men.xlsx'
    else:
        size_chart_path = r'C:\Users\bhavi\Downloads\women.xlsx'
    
    size_chart = pd.read_excel(size_chart_path)
    size_chart_info = size_chart.head(10) 
    size_chart_str = size_chart_info.to_string(index=False)

    prompt = (
        f"A user is {height}cm tall, weighs {weight}kg, and is looking for a general size recommendation for a {product_fit} item of clothing for {gender}. "
        f"Here is the size chart information for reference:\n\n"
        f"{size_chart_str}\n\n"
        f"Based on just the user's height and weight, what size would you recommend from this size chart? The size chart gives size given height in cm and weight in kg "
        f"Please provide a general size recommendation without considering anything else. You can give a guess as well. Don't give any extra information. Just the recommended size in one line"
    )
    
    completion = model.generate_content(prompt)
    text_out = completion.text if completion else "Size prediction not available"

    return text_out

# Initialize Streamlit app
def main():
    st.sidebar.title("Navigation")
    page = st.sidebar.radio("Go to", ["Our Collection", "Your Purchases", "Your Closet"])

    # Centralize all titles using custom CSS
    st.markdown("""
        <style>
        .center-title {
            text-align: center;
        }
        .center-content {
            display: flex;
            justify-content: center;
            align-items: center;
        }
        .theme-button {
            border: none;
            background-color: transparent;
            cursor: pointer;
        }
        </style>
        """, unsafe_allow_html=True)

    logo_image_path = r'C:\Users\bhavi\Downloads\logo_image.jpg'
    if os.path.exists(logo_image_path):
        logo_image = Image.open(logo_image_path)

        # Define CSS style to center align the image
        st.markdown(
            """
            <style>
            .centered {
                display: flex;
                justify-content: center;
            }
            </style>
            """,
            unsafe_allow_html=True
        )

        # Display the image inside a centered div
        st.markdown('<div class="centered">', unsafe_allow_html=True)
        st.image(logo_image, width=150, caption='', use_column_width=False)
        st.markdown('</div>', unsafe_allow_html=True)

    else:
        st.error("Logo image not found.")

    # Check if a theme is selected
    if 'selected_theme' in st.session_state:
        theme = st.session_state['selected_theme']
        if theme == "Harvey Spectre's Closet":
            st.markdown("<h1 class='center-title'>Harvey Spectre's Closet</h1>", unsafe_allow_html=True)
            data_theme = load_data(r'C:\Users\bhavi\Downloads\harvey.xlsx')
            image_path = r'C:\Users\bhavi\Downloads\harvey_image.jpg'

        elif theme == "Bridgerton":
            st.markdown("<h1 class='center-title'>Bridgerton Closet</h1>", unsafe_allow_html=True)
            data_theme = load_data(r'C:\Users\bhavi\Downloads\bridgerton.xlsx')
            image_path = r'C:\Users\bhavi\Downloads\bridgerton_image.jpg'

        #st.image(image_path, width=300)
        st.markdown(f" Welcome to The {theme}! Choose your outfit from the options below ")

        cols = st.columns(3)
        for index, row in data_theme.iterrows():
            col = cols[index % 3]
            with col:
                image = Image.open(row['image_path']).resize((200, 200))
                st.image(image, width=200)
                st.write(f"**{row['name']}**")
                st.write(f"Price: Rs.{row['price']}")
                st.write("---")

                # Add Size Recommendation button and form
                if row['Gender'] == 'W':
                    with st.expander("Size Recommendation", expanded=False):
                        with st.form(key=f"{index}_{row['name']}_form"):
                            st.write("Click the button below to get size recommendations.")
                            
                            # Form inputs
                            height = st.number_input("Height (cm)", min_value=112, max_value=300, step=1, key=f"{index}_height")
                            weight = st.number_input("Weight (kg)", min_value=40, max_value=300, step=1, key=f"{index}_weight")
                            product_fit = row['Fit']  # Assuming Fit is directly available from the row
                            
                            # Submit button
                            submit_button = st.form_submit_button("Predict Size")
                            if submit_button:
                                predicted_size = predict_size(height, weight, None, row['Gender'], product_fit)
                                st.success(f"Predicted Size for {row['name']}: {predicted_size}")

                elif row['Gender'] == 'M':
                    with st.expander("Size Recommendation", expanded=False):
                        with st.form(key=f"{index}_{row['name']}_form"):
                            st.write("Click the button below to get size recommendations.")
                            
                            # Form inputs
                            height = st.number_input("Height (cm)", min_value=150, max_value=300, step=1, key=f"{index}_height")
                            weight = st.number_input("Weight (kg)", min_value=50, max_value=300, step=1, key=f"{index}_weight")
                            product_fit = row['Fit']

                            # Submit button
                            submit_button = st.form_submit_button("Predict Size")
                            if submit_button:
                                predicted_size = predict_size(height, weight, None, row['Gender'], product_fit)
                                st.success(f"Predicted Size for {row['name']}: {predicted_size}")

                # Add Virtual Try-On dropdown menu
                with st.expander("Virtual Try-On", expanded=False):
                    avatar_image = st.file_uploader("Upload Your Avatar Image", type=["jpg", "png", "jpeg"], key=f"avatar_{index}")

                    if avatar_image:
                        if st.button("Try-On", key=f"try_on_{index}"):
                            look_image_path = row['image_path']  # Path to the look image
                            result_image_path = virtual_try_on(look_image_path, avatar_image)

                            if result_image_path:
                                result_image = Image.open(result_image_path)
                                st.image(result_image, caption="Virtual Try-On Result", use_column_width=True)
                            else:
                                st.error("Failed to perform virtual try-on.")
        return

    if page == "Our Collection":
        st.markdown("<h1 class='center-title'>Our Collection</h1>", unsafe_allow_html=True)
        st.header("Themes")

        # Display theme images and clickable boxes
        harvey_image_path = r'C:\Users\bhavi\Downloads\harvey_image.jpg'
        bridgerton_image_path = r'C:\Users\bhavi\Downloads\bridgerton_image.jpg'

        cols = st.columns([1, 1])

        with cols[0]:
            harvey_image = Image.open(harvey_image_path).resize((200, 250))
            st.image(harvey_image, use_column_width=True)
            if st.button("Harvey Spectre's Closet"):
                st.session_state['selected_theme'] = "Harvey Spectre's Closet"
                st.experimental_rerun()  # Refresh the page to reflect the selected theme

        with cols[1]:
            bridgerton_image = Image.open(bridgerton_image_path).resize((200, 250))
            st.image(bridgerton_image, use_column_width=True)
            if st.button("Bridgerton Closet"):
                st.session_state['selected_theme'] = "Bridgerton"
                st.experimental_rerun()  # Refresh the page to reflect the selected theme

        st.header("Collection")

        # Load collection data
        data_collection = load_data(r'C:\Users\bhavi\Downloads\myntra_collection_sample.xlsx')

        # Display clothes in three columns
        cols = st.columns(3)
        for index, row in data_collection.iterrows():
            col = cols[index % 3]
            with col:
                image = Image.open(row['image_path']).resize((200, 200))
                st.image(image, width=200)
                st.write(f"**{row['name']}**")
                st.write(f"Price: Rs.{row['price']}")
                st.write("---")

                # Add Size Recommendation button and form
                if row['Gender'] == 'W':
                    with st.expander("Size Recommendation", expanded=False):
                        with st.form(key=f"{index}_{row['name']}_form"):
                            st.write("Click the button below to get size recommendations.")
                            
                            # Form inputs
                            height = st.number_input("Height (cm)", min_value=112, max_value=300, step=1, key=f"{index}_height")
                            weight = st.number_input("Weight (kg)", min_value=40, max_value=300, step=1, key=f"{index}_weight")
                            product_fit = row['Fit']  # Assuming Fit is directly available from the row
                            
                            # Submit button
                            submit_button = st.form_submit_button("Predict Size")
                            if submit_button:
                                predicted_size = predict_size(height, weight, None, row['Gender'], product_fit)
                                st.success(f"Predicted Size for {row['name']}: {predicted_size}")

                elif row['Gender'] == 'M':
                    with st.expander("Size Recommendation", expanded=False):
                        with st.form(key=f"{index}_{row['name']}_form"):
                            st.write("Click the button below to get size recommendations.")
                            
                            # Form inputs
                            height = st.number_input("Height (cm)", min_value=150, max_value=300, step=1, key=f"{index}_height")
                            weight = st.number_input("Weight (kg)", min_value=50, max_value=300, step=1, key=f"{index}_weight")
                            product_fit = row['Fit']

                            # Submit button
                            submit_button = st.form_submit_button("Predict Size")
                            if submit_button:
                                predicted_size = predict_size(height, weight, None, row['Gender'], product_fit)
                                st.success(f"Predicted Size for {row['name']}: {predicted_size}")

                # Add Virtual Try-On dropdown menu
                with st.expander("Virtual Try-On", expanded=False):
                    avatar_image = st.file_uploader("Upload Your Avatar Image", type=["jpg", "png", "jpeg"], key=f"avatar_{index}")

                    if avatar_image:
                        if st.button("Try-On", key=f"try_on_{index}"):
                            look_image_path = row['image_path']  # Path to the look image
                            result_image_path = virtual_try_on(look_image_path, avatar_image)

                            if result_image_path:
                                result_image = Image.open(result_image_path)
                                st.image(result_image, caption="Virtual Try-On Result", use_column_width=True)
                            else:
                                st.error("Failed to perform virtual try-on.")


                
    elif page == "Your Purchases":
        st.markdown("<h2 class='center-title'>Your Purchases</h2>", unsafe_allow_html=True)

        # Load purchases data
        data_purchases = load_data(r'C:\Users\bhavi\Downloads\myntra_csv.xlsx')

        for index, row in data_purchases.iterrows():
            image = Image.open(row['image_path'])
            st.image(image, width=300)
            st.write(f"**{row['name']}**")
            st.write(f"Price: Rs.{row['price']}")
            st.write(f"Description: {row['description']}")
            multiselect_key = f"{index}_{row['name']}_multiselect"
            occasions = st.multiselect(f"Select occasions to add {row['name']} to:", ["Casual", "Office", "Party", "Formal"],
                                       key=multiselect_key)
            add_button_key = f"{index}_{row['name']}_add_button"
            if st.button(f"Add {row['name']} to selected playlists", key=add_button_key):
                for occasion in occasions:
                    add_to_playlist(occasion, row.to_dict())
            st.write("---")

    elif page == "Your Closet":
        st.markdown("<h1 class='center-title'>Your Closet</h1>", unsafe_allow_html=True)

        # Option to create a new playlist
        new_playlist_name = st.text_input("Create a new playlist")
        if st.button("Create Playlist"):
            if new_playlist_name and new_playlist_name not in st.session_state['playlists']:
                st.session_state['playlists'][new_playlist_name] = []
                st.success(f'Playlist "{new_playlist_name}" created successfully!')
            elif new_playlist_name in st.session_state['playlists']:
                st.warning(f'Playlist "{new_playlist_name}" already exists.')
            else:
                st.warning("Please enter a valid playlist name.")

        # Display selectable playlists (occasions)
        if st.session_state['playlists']:
            selected_occasion = st.selectbox("Select occasion to view items:", list(st.session_state['playlists'].keys()))
        else:
            selected_occasion = None
            st.warning("No playlists available. Please create a new playlist.")

        if selected_occasion:
            st.markdown(f"<h2 class='center-title'>{selected_occasion} Playlist</h2>", unsafe_allow_html=True)

            st.subheader(f'Upload New Item to {selected_occasion} Playlist')
            # Upload new item to selected playlist
            uploaded_file = st.file_uploader("Choose an image...", type=["jpg", "png", "jpeg"])
            if uploaded_file:
                item_name = st.text_input("Enter item name")
                item_description = st.text_area("Enter item description")
                if st.button(f"Add new item to {selected_occasion} playlist"):
                    file_path = save_uploaded_file(uploaded_file)
                    new_item = {
                        "image_path": file_path,
                        "name": item_name,
                        "description": item_description
                    }
                    add_to_playlist(selected_occasion, new_item)

            # Display items in selected playlist
            for item in st.session_state['playlists'][selected_occasion]:
                image = Image.open(item['image_path'])
                st.image(image, width=300)
                st.write(f"**{item['name']}**")
                st.write(f"Description: {item['description']}")
                remove_button_key = f"{selected_occasion}_{item['name']}_remove_button"
                if st.button(f"Remove {item['name']} from {selected_occasion} playlist", key=remove_button_key):
                    remove_from_playlist(selected_occasion, item['name'])
                st.write("---")



if __name__ == "__main__":
    main()













































# # Load the datasets
# @st.cache_data
# def load_data(file_path):
#     data = pd.read_excel(file_path)
#     data['image_path'] = data['image_path'].apply(lambda x: x.replace('\\', '/'))
#     return data

# # Load theme-specific data
# @st.cache_data
# def load_theme_data(file_path):
#     data = pd.read_csv(file_path)
#     data['image_path'] = data['image_path'].apply(lambda x: x.replace('\\', '/'))
#     return data

# def predict_size(height, weight, body_shape, gender):
#     # Example rule-based prediction
#     bmi = weight / ((height / 100) ** 2)
    
#     if gender == 'F':
#         # Women's sizing recommendation
#         if body_shape == "Hourglass":
#             if bmi < 18.5:
#                 return "XS"
#             elif 18.5 <= bmi < 24.9:
#                 return "S"
#             elif 24.9 <= bmi < 29.9:
#                 return "M"
#             elif bmi >= 29.9:
#                 return "L"
#         elif body_shape == "Apple":
#             if bmi < 20:
#                 return "S"
#             elif 20 <= bmi < 25:
#                 return "M"
#             elif bmi >= 25:
#                 return "L"
#         elif body_shape == "Pear":
#             if bmi < 21:
#                 return "S"
#             elif 21 <= bmi < 26:
#                 return "M"
#             elif bmi >= 26:
#                 return "L"
#         elif body_shape == "Rectangle":
#             if bmi < 19:
#                 return "S"
#             elif 19 <= bmi < 24:
#                 return "M"
#             elif bmi >= 24:
#                 return "L"
#         elif body_shape == "Triangle":
#             if bmi < 20:
#                 return "S"
#             elif 20 <= bmi < 25:
#                 return "M"
#             elif bmi >= 25:
#                 return "L"

#     elif gender == 'M':
#         # Men's sizing recommendation
#         if bmi < 20:
#             return "XS"
#         elif 20 <= bmi < 25:
#             return "S"
#         elif 25 <= bmi < 30:
#             return "M"
#         elif bmi >= 30:
#             return "L"
    
#     # Default return
#     return "M"  # Default size recommendation

# data_purchases = load_data(r'C:\Users\bhavi\Downloads\myntra_csv.xlsx')
# data_collection = load_data(r'C:\Users\bhavi\Downloads\myntra_collection_sample.xlsx')

# if not os.path.exists('uploads'):
#     os.makedirs('uploads')

# if 'playlists' not in st.session_state:
#     st.session_state['playlists'] = {}


# def add_to_playlist(occasion, item):
#     if occasion not in st.session_state['playlists']:
#         st.session_state['playlists'][occasion] = []
#     # Check if item is already in the playlist
#     if item not in st.session_state['playlists'][occasion]:
#         st.session_state['playlists'][occasion].append(item)
#         st.success(f'Added {item["name"]} to {occasion} playlist')
#     else:
#         st.warning(f'{item["name"]} is already in {occasion} playlist')


# def save_uploaded_file(uploaded_file):
#     file_path = os.path.join('uploads', uploaded_file.name)
#     with open(file_path, 'wb') as f:
#         f.write(uploaded_file.getbuffer())
#     return file_path


# def remove_from_playlist(occasion, item_name):
#     if occasion in st.session_state['playlists']:
#         st.session_state['playlists'][occasion] = [item for item in st.session_state['playlists'][occasion] if
#                                                    item['name'] != item_name]
#         st.success(f'Removed {item_name} from {occasion} playlist')


# st.sidebar.title("Navigation")
# page = st.sidebar.radio("Go to", ["Our Collection", "My Purchases", "Your Closet"])

# # Centralize all titles using custom CSS
# st.markdown("""
#     <style>
#     .center-title {
#         text-align: center;
#     }
#     .center-content {
#         display: flex;
#         justify-content: center;
#         align-items: center;
#     }
#     .theme-button {
#         border: none;
#         background-color: transparent;
#         cursor: pointer;
#     }
#     </style>
#     """, unsafe_allow_html=True)

# logo_image_path = r'C:\Users\bhavi\Downloads\logo_image.jpg'
# if os.path.exists(logo_image_path):
#     logo_image = Image.open(logo_image_path)

#     # Define CSS style to center align the image
#     st.markdown(
#         """
#         <style>
#         .centered {
#             display: flex;
#             justify-content: center;
#         }
#         </style>
#         """,
#         unsafe_allow_html=True
#     )

#     # Display the image inside a centered div
#     st.markdown('<div class="centered">', unsafe_allow_html=True)
#     st.image(logo_image, width=150, caption='', use_column_width=False)
#     st.markdown('</div>', unsafe_allow_html=True)

# else:
#     st.error("Logo image not found.")

# if page == "Our Collection":
#     st.markdown("<h1 class='center-title'>Our Collection</h1>", unsafe_allow_html=True)
#     st.header("Themes")

#     # Display theme images and clickable boxes
#     harvey_image_path = r'C:\Users\bhavi\Downloads\harvey_image.jpg'
#     bridgerton_image_path = r'C:\Users\bhavi\Downloads\bridgerton_image.jpg'

#     cols = st.columns([1, 1])

#     with cols[0]:
#         harvey_image = Image.open(harvey_image_path).resize((200, 250))
#         st.image(harvey_image, use_column_width=True)
#         harvey_button_key = "harvey_button"
#         if st.button("Harvey Spectre's Closet", key=harvey_button_key):
#             st.session_state['selected_theme'] = "Harvey Spectre's Closet"
#             st.experimental_rerun()

#     with cols[1]:
#         bridgerton_image = Image.open(bridgerton_image_path).resize((200, 250))
#         st.image(bridgerton_image, use_column_width=True)
#         bridgerton_button_key = "bridgerton_button"
#         if st.button("Bridgerton Closet", key=bridgerton_button_key):
#             st.session_state['selected_theme'] = "Bridgerton"
#             st.experimental_rerun()

#     st.header("Collection")

#     # Display clothes in three columns
#     cols = st.columns(3)
#     for index, row in data_collection.iterrows():
#         col = cols[index % 3]
#         with col:
#             image = Image.open(row['image_path']).resize((200, 200))
#             st.image(image, width=200)
#             st.write(f"**{row['name']}**")
#             st.write(f"Price: Rs.{row['price']}")
#             st.write("---")

#             # Add Size Recommendation button for women's items
#             # Add Size Recommendation button for women's items
#             if row['Gender'] == 'W':
#                 form_key = f"{index}_{row['name']}_form"
#                 with st.form(key=form_key):
#                     height = st.number_input("Height (cm)", min_value=100, max_value=300, step=1)
#                     weight = st.number_input("Weight (kg)", min_value=20, max_value=300, step=1)
#                     body_shape = st.selectbox("Body Shape", ["Hourglass", "Apple", "Pear", "Rectangle", "Triangle"])
#                     submit_button = st.form_submit_button("Predict Size")
#                     if submit_button:
#                         predicted_size = predict_size(height, weight, body_shape, row['Gender'])
#                         st.success(f"Predicted Size for {row['name']}: {predicted_size}")

#             # Add Size Recommendation button for men's items
#             elif row['Gender'] == 'M':
#                 form_key = f"{index}_{row['name']}_form"
#                 with st.form(key=form_key):
#                     height = st.number_input("Height (cm)", min_value=100, max_value=300, step=1)
#                     weight = st.number_input("Weight (kg)", min_value=20, max_value=300, step=1)
#                     submit_button = st.form_submit_button("Predict Size")
#                     if submit_button:
#                         predicted_size = predict_size(height, weight, None, row['Gender'])
#                         st.success(f"Predicted Size for {row['name']}: {predicted_size}")


# elif page == "My Purchases":
#     st.markdown("<h2 class='center-title'>My Purchases</h2>", unsafe_allow_html=True)

#     for index, row in data_purchases.iterrows():
#         image = Image.open(row['image_path'])
#         st.image(image, width=300)
#         st.write(f"**{row['name']}**")
#         st.write(f"Price: Rs.{row['price']}")
#         st.write(f"Description: {row['description']}")
#         # Generate a unique key based on index and name
#         multiselect_key = f"{index}_{row['name']}_multiselect"
#         occasions = st.multiselect(f"Select occasions to add {row['name']} to:", ["Casual", "Office", "Party", "Formal"],
#                                    key=multiselect_key)
#         add_button_key = f"{index}_{row['name']}_add_button"
#         if st.button(f"Add {row['name']} to selected playlists", key=add_button_key):
#             for occasion in occasions:
#                 add_to_playlist(occasion, row.to_dict())
#         st.write("---")

# elif page == "Your Closet":
#     st.markdown("<h1 class='center-title'>Your Closet</h1>", unsafe_allow_html=True)

#     # Option to create a new playlist
#     new_playlist_name = st.text_input("Create a new playlist")
#     if st.button("Create Playlist"):
#         if new_playlist_name and new_playlist_name not in st.session_state['playlists']:
#             st.session_state['playlists'][new_playlist_name] = []
#             st.success(f'Playlist "{new_playlist_name}" created successfully!')
#         elif new_playlist_name in st.session_state['playlists']:
#             st.warning(f'Playlist "{new_playlist_name}" already exists.')
#         else:
#             st.warning("Please enter a valid playlist name.")

#     # Display selectable playlists (occasions)
#     if st.session_state['playlists']:
#         selected_occasion = st.selectbox("Select occasion to view items:", list(st.session_state['playlists'].keys()))
#     else:
#         selected_occasion = None
#         st.warning("No playlists available. Please create a new playlist.")

#     if selected_occasion:
#         st.markdown(f"<h2 class='center-title'>{selected_occasion} Playlist</h2>", unsafe_allow_html=True)

#         st.subheader(f'Upload New Item to {selected_occasion} Playlist')
#         # Upload new item to selected playlist
#         uploaded_file = st.file_uploader("Choose an image...", type=["jpg", "png", "jpeg"])
#         if uploaded_file:
#             item_name = st.text_input("Enter item name")
#             # item_price = st.text_input("Enter item price")
#             item_description = st.text_area("Enter item description")
#             if st.button(f"Add new item to {selected_occasion} playlist"):
#                 file_path = save_uploaded_file(uploaded_file)
#                 new_item = {
#                     "image_path": file_path,
#                     "name": item_name,
#                     # "price": item_price,
#                     "description": item_description
#                 }
#                 add_to_playlist(selected_occasion, new_item)

#         # Display items in selected playlist
#         for item in st.session_state['playlists'][selected_occasion]:
#             image = Image.open(item['image_path'])
#             st.image(image, width=300)
#             st.write(f"**{item['name']}**")
#             # st.write(f"Price: ${item['price']}")
#             st.write(f"Description: {item['description']}")
#             remove_button_key = f"{selected_occasion}_{item['name']}_remove_button"
#             if st.button(f"Remove {item['name']} from {selected_occasion} playlist", key=remove_button_key):
#                 remove_from_playlist(selected_occasion, item['name'])
#             st.write("---")

# elif 'selected_theme' in st.session_state:
#     theme = st.session_state['selected_theme']
#     if theme == "Harvey Spectre's Closet":
#         st.markdown("<h1 class='center-title'>Harvey Spectre's Closet</h1>", unsafe_allow_html=True)
#         data_harvey = load_theme_data(r'C:\Users\bhavi\Downloads\harvey_output.csv')

#         cols = st.columns(3)
#         for index, row in data_harvey.iterrows():
#             col = cols[index % 3]
#             with col:
#                 image = Image.open(row['image_path']).resize((200, 200))
#                 st.image(image, width=200)
#                 st.write(f"**{row['name']}**")
#                 st.write(f"Price: Rs.{row['price']}")
#                 st.write("---")

#     elif theme == "Bridgerton":
#         st.markdown("<h1 class='center-title'>Bridgerton</h1>", unsafe_allow_html=True)
#         data_bridgerton = load_theme_data(r'C:\Users\bhavi\Downloads\bridgerton_output.csv')

#         cols = st.columns(3)
#         for index, row in data_bridgerton.iterrows():
#             col = cols[index % 3]
#             with col:
#                 image = Image.open(row['image_path']).resize((200, 200))
#                 st.image(image, width=200)
#                 st.write(f"**{row['name']}**")
#                 st.write(f"Price: Rs.{row['price']}")
#                 st.write("---")
